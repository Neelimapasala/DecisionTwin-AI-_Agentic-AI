# Evaluation plan

- Compare forecasting against seasonal naive on temporal holdout once real training is implemented.
- Build 100+ labeled prompts and report parsing precision and schema validation failures.
- Test constraints, reproducibility, injection resilience, and unsupported causal claims.
- Compare synthetic intervention effect estimates against known generating parameters.
- Do not publish benchmark numbers until measured.
