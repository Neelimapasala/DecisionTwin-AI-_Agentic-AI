# Architecture

React/Vite → FastAPI → validated scenario parser → deterministic simulation engine → trace + computed insights.

The intent parser optionally uses Groq; the numeric engine never uses LLM-generated figures. This starter has no database or LangGraph runtime yet.
