# LinkedIn demo storyboard

1. Problem: dashboards describe the past; decisions require assumptions and uncertainty.
2. Enter a natural-language scenario and show extracted controls.
3. Run the simulation; compare baseline and outcome.
4. Open the trace and assumptions tabs; disclose limitations.
5. Link the repo, evaluation, and roadmap.

Never describe unimplemented LangGraph, trained causal inference, or validated forecasts as complete.
