import random
from .schemas import Scenario

BASELINE = {"revenue": 1000000, "marketing": 100000, "operating": 200000, "variable": 500000}
ASSUMPTIONS = {"marketing_demand_coefficient": 0.12, "price_elasticity": -1.2, "monthly_demand_noise_std": 0.06, "source": "Illustrative assumptions; not fitted to real data"}

def metrics(s: Scenario, demand_shock: float = 0.0):
    volume = max(0.1, 1 + 0.12 * s.marketing_change_pct / 100 - 1.2 * s.price_change_pct / 100 + demand_shock)
    revenue = BASELINE["revenue"] * (1 + s.price_change_pct / 100) * volume
    marketing = BASELINE["marketing"] * (1 + s.marketing_change_pct / 100)
    operating = BASELINE["operating"] * (1 - s.operating_cost_reduction_pct / 100)
    variable = BASELINE["variable"] * volume
    return {k: round(v, 2) for k, v in {"revenue": revenue, "marketing": marketing, "operating": operating, "variable": variable, "profit": revenue-marketing-operating-variable, "volume_index": volume}.items()}

def simulate(s: Scenario):
    rng = random.Random(s.seed)
    samples = sorted(metrics(s, rng.gauss(0, 0.06))["profit"] for _ in range(s.iterations))
    baseline = metrics(Scenario(marketing_change_pct=0, price_change_pct=0, operating_cost_reduction_pct=0))
    scenario = metrics(s)
    return {"baseline": baseline, "scenario": scenario, "profit_change_pct": round((scenario["profit"] / baseline["profit"] - 1) * 100, 2), "profit_uncertainty": {"p05": samples[int(0.05*(len(samples)-1))], "median": samples[len(samples)//2], "p95": samples[int(0.95*(len(samples)-1))]}, "assumptions": ASSUMPTIONS, "disclaimer": "Illustrative, assumption-driven simulation. Not a causal estimate or validated forecast.", "trace": [{"agent":"Intent Agent","status":"completed","detail":"Validated scenario fields"},{"agent":"Data Agent","status":"completed","detail":"Loaded illustrative retail baseline"},{"agent":"Risk Agent","status":"completed","detail":"Checked input constraints; causal effects unverified"},{"agent":"Simulation Tool","status":"completed","detail":f"Executed {s.iterations} seeded draws"},{"agent":"Insight Agent","status":"completed","detail":"Derived comparison from computed results"}]}
