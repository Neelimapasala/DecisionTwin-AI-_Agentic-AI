import os
import re
import json
from urllib.request import Request, urlopen
from .schemas import Scenario

PATTERNS = {
    "marketing_change_pct": r"(?:marketing|advertising|ad spend|ad budget)[^.%\n]{0,65}?([+-]?\d+(?:\.\d+)?)\s*%",
    "price_change_pct": r"(?:price|pricing)[^.%\n]{0,65}?([+-]?\d+(?:\.\d+)?)\s*%",
    "operating_cost_reduction_pct": r"(?:operating costs?|operational costs?|expenses?)[^.%\n]{0,65}?([+-]?\d+(?:\.\d+)?)\s*%",
}

def local_parse(prompt: str):
    text = prompt.lower()
    vals = {}
    for field, pattern in PATTERNS.items():
        match = re.search(pattern, text)
        if match:
            val = float(match.group(1))
            context = text[max(0,match.start()-15):match.end()]
            if field == "operating_cost_reduction_pct":
                if any(w in context for w in ("increase", "raise")):
                    raise ValueError("Operating cost increases are not supported; use cost reduction.")
            elif any(w in context for w in ("reduce", "decrease", "lower", "cut")):
                val = -abs(val)
            vals[field] = val
    if not vals:
        raise ValueError("Specify a percentage change for marketing, price, or operating costs, e.g. 'increase marketing 15%'.")
    return Scenario(**vals)

def parse(prompt: str):
    if os.getenv("USE_GROQ", "false").lower() != "true" or not os.getenv("GROQ_API_KEY"):
        return local_parse(prompt)
    system = "Extract scenario fields from the user request. Return ONLY JSON with optional keys marketing_change_pct, price_change_pct, operating_cost_reduction_pct. Cost reduction is nonnegative. Use negative values for marketing/price decreases. Never invent changes not stated."
    payload = json.dumps({"model": os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"), "messages": [{"role":"system","content":system},{"role":"user","content":prompt}], "temperature":0, "response_format":{"type":"json_object"}}).encode()
    req = Request("https://api.groq.com/openai/v1/chat/completions", data=payload, headers={"Authorization":"Bearer "+os.environ["GROQ_API_KEY"],"Content-Type":"application/json"})
    with urlopen(req, timeout=15) as resp:
        obj = json.loads(json.load(resp)["choices"][0]["message"]["content"])
    if not isinstance(obj, dict) or not set(obj).intersection({"marketing_change_pct","price_change_pct","operating_cost_reduction_pct"}):
        raise ValueError("No supported scenario variables found")
    return Scenario.model_validate(obj)
