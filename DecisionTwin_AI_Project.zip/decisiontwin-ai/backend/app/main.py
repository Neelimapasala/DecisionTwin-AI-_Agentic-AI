from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError
from .schemas import Scenario, ParseRequest, CompareRequest
from .engine import BASELINE, ASSUMPTIONS, simulate
from .parser import parse

app = FastAPI(title="DecisionTwin AI", version="0.1.0", description="Illustrative scenario simulation API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["GET", "POST"], allow_headers=["*"])

@app.get("/api/health")
def health(): return {"status": "ok", "version": "0.1.0"}

@app.get("/api/baseline")
def baseline(): return {"baseline": BASELINE, "assumptions": ASSUMPTIONS}

@app.post("/api/scenarios/parse")
def parse_scenario(req: ParseRequest):
    try: return {"scenario": parse(req.prompt).model_dump()}
    except (ValueError, ValidationError) as exc: raise HTTPException(status_code=422, detail=str(exc))
    except Exception: raise HTTPException(status_code=502, detail="LLM parsing failed; disable USE_GROQ to use local parsing")

@app.post("/api/simulations")
def run_simulation(s: Scenario): return simulate(s)

@app.post("/api/scenarios/compare")
def compare(req: CompareRequest): return {"results": [simulate(s) for s in req.scenarios]}
