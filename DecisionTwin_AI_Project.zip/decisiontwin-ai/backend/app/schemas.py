from pydantic import BaseModel, Field

class Scenario(BaseModel):
    marketing_change_pct: float = Field(default=15, ge=-50, le=100)
    price_change_pct: float = Field(default=0, ge=-30, le=50)
    operating_cost_reduction_pct: float = Field(default=5, ge=0, le=50)
    iterations: int = Field(default=1000, ge=100, le=10000)
    seed: int = 42

class ParseRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=2000)

class CompareRequest(BaseModel):
    scenarios: list[Scenario] = Field(min_length=1, max_length=5)
