from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get('/api/health').json()['status'] == 'ok'

def test_parse():
    res = client.post('/api/scenarios/parse', json={'prompt':'increase marketing by 20% and reduce operating costs by 10%'})
    assert res.status_code == 200
    assert res.json()['scenario']['marketing_change_pct'] == 20
    assert res.json()['scenario']['operating_cost_reduction_pct'] == 10

def test_determinism():
    payload={'marketing_change_pct': 15, 'seed': 42}
    a=client.post('/api/simulations',json=payload).json()
    b=client.post('/api/simulations',json=payload).json()
    assert a == b
    assert a['baseline']['profit'] == 200000

def test_constraints():
    assert client.post('/api/simulations',json={'price_change_pct': 90}).status_code == 422
