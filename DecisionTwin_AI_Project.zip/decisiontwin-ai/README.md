# DecisionTwin AI — Agentic Decision Simulation Starter

A runnable full-stack portfolio MVP: natural-language scenario parsing, deterministic scenario simulation, transparent assumptions, scenario comparison, and an agent execution trace. **This is a starter implementation, not a validated causal inference or production forecasting system.**

## Quick start

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Backend: http://localhost:8000/docs

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## Included
- React + Vite + TypeScript responsive dark dashboard
- FastAPI REST endpoints with typed Pydantic schemas
- Rule-based natural-language intent parser (runs without API keys)
- Deterministic financial what-if simulation with a seeded Monte Carlo uncertainty band
- Baseline and scenario comparison, assumptions, agent trace
- Pytest tests, Docker backend, sample dataset, project docs

## Optional Groq LLM parser
Set `GROQ_API_KEY` in the backend environment and set `USE_GROQ=true`. This enables LLM-based structured intent extraction with a strict Pydantic validation step; the fallback parser remains available. See `.env.example`. No keys are bundled.

## Assumptions and limitations
- Illustrative retail baseline: monthly revenue ₹10,00,000, marketing ₹1,00,000, operating costs ₹2,00,000, variable costs ₹5,00,000.
- Demand responds to marketing and price through **assumed coefficients**, not learned or causally identified effects.
- Uncertainty is a configurable toy demand-noise model, **not calibrated prediction intervals**.
- Results must not be used for real financial decisions without validation.
- Agents are currently an explicit, inspectable pipeline; LangGraph, RAG, database persistence, trained forecasting, and causal identification are extension milestones, not falsely advertised as implemented.

## Roadmap
1. Train a forecasting baseline on Rossmann data with time-based validation.
2. Add PostgreSQL, model registry, and persisted audit logs.
3. Replace pipeline with LangGraph typed state and checkpoints.
4. Add assumption graph, documented causal methods, and sensitivity analysis.
5. Implement auth, worker queue, observability, and security evaluation.

## API
- `GET /api/health`
- `GET /api/baseline`
- `POST /api/scenarios/parse`
- `POST /api/simulations`
- `POST /api/scenarios/compare`

## License
MIT.
